@echo off
setlocal
title Install Yangzhi Custom CLI

echo.
echo  Yangzhi Audiobook Forge - Custom CLI Installer
echo  ------------------------------------------------
echo.
echo  Select the ROOT of your NEW Chatterbox-TTS-Server v2 folder.
echo  It must already contain start.bat.
echo.

set "TARGET="
set /p "TARGET=Paste the full folder path here: "
set "TARGET=%TARGET:"=%"

if not defined TARGET (
  echo.
  echo [ERROR] No folder was entered.
  pause
  exit /b 1
)

if not exist "%TARGET%\start.bat" (
  echo.
  echo [ERROR] start.bat was not found in:
  echo %TARGET%
  echo.
  echo Choose the root of the official v2 installation, not a subfolder.
  pause
  exit /b 1
)

if not exist "%~dp0cbx_turbo_cli.py" (
  echo.
  echo [ERROR] cbx_turbo_cli.py is missing from this update kit.
  pause
  exit /b 1
)

if exist "%TARGET%\cbx_turbo_cli.py" (
  copy /y "%TARGET%\cbx_turbo_cli.py" "%TARGET%\cbx_turbo_cli.py.pre-yangzhi-backup" >nul
  if errorlevel 1 (
    echo.
    echo [ERROR] Could not back up the existing CLI.
    pause
    exit /b 1
  )
  echo [OK] Existing CLI backed up as cbx_turbo_cli.py.pre-yangzhi-backup
)

copy /y "%~dp0cbx_turbo_cli.py" "%TARGET%\cbx_turbo_cli.py" >nul
if errorlevel 1 (
  echo.
  echo [ERROR] Copy failed. Check folder permissions and try again.
  pause
  exit /b 1
)

echo.
echo [SUCCESS] The custom CLI is installed at:
echo %TARGET%\cbx_turbo_cli.py
echo.
echo Open Yangzhi Audiobook Forge and select this v2 folder.
pause
exit /b 0
