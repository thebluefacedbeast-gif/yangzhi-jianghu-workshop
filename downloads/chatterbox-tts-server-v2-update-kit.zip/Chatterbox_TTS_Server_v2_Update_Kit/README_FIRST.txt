CHATTERBOX TTS SERVER v2 — SAFE UPDATE KIT
For Yangzhi Audiobook Forge v1.2

PURPOSE
This kit adds the custom Yangzhi audiobook CLI to a fresh official
Chatterbox-TTS-Server v2 portable installation. It does not contain or replace
the official server, Python runtime, PyTorch, or model files.

SAFE SIDE-BY-SIDE SETUP

1. Keep your current working Chatterbox folder unchanged.

2. Download the official Chatterbox-TTS-Server v2.0.0 release:
   https://github.com/devnen/Chatterbox-TTS-Server/releases/tag/v2.0.0

3. Extract it into a NEW folder. A clear name is:
   Chatterbox-TTS-Server-v2-CPU

4. Open the new folder and run start.bat.

5. Choose Portable Mode and CPU installation when prompted.
   Let setup finish and allow the Turbo model to download/load.

6. Test the official server once before adding anything custom.

7. Close the server. Copy cbx_turbo_cli.py from this kit into the ROOT of the
   new server folder, beside start.bat. You can do this manually or run:
   Install_Custom_CLI.bat

8. If desired, copy your own reference recordings into the new installation.
   Do not overwrite configuration files unless you know you need the old values.

9. Open Yangzhi Audiobook Forge. Select the NEW server folder when asked.

10. Generate a short 2–3 sentence test. Confirm that the WAV is created and
    plays correctly before attempting a full poem or chapter.

CUSTOM CLI FEATURES

- Preserves poem line breaks and stanza spacing.
- Keeps all nine supported Turbo reaction tags with nearby speech.
- Makes the Forge Seed field control Python, NumPy, and PyTorch randomness.
- Uses one fixed seed across every chunk and prints it in the Generation Log.
- Saves output as [text][reference][style][speed][seed].wav.

EXPECTED ROOT LAYOUT

Chatterbox-TTS-Server-v2-CPU\
|-- start.bat
|-- cbx_turbo_cli.py       <- supplied by this kit
|-- python_embedded\        <- created by Portable Mode
|   `-- python.exe
|-- reference_audio\        <- optional voice samples
`-- other official v2 files and folders

IMPORTANT

- Do not extract v2 over your old working installation.
- Do not delete the old installation until Forge passes a complete test.
- The ComfyUI-ChatterBox-Turbo project is not a drop-in replacement.
- Use only voices you own or have explicit permission to clone.

ROLLBACK

If the new installation fails, close it and point Yangzhi Audiobook Forge back
to your original working Chatterbox folder. Nothing in this kit modifies the
old installation.
